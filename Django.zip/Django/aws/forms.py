from django.forms import ModelForm
from .models import Customer, Itinerary

class CustomerForm(ModelForm):
    class Meta:
        model = Customer
        fields=[
            "email",

                ]


class Itinerary(ModelForm):
    class Meta:
        model = Itinerary
        fields=[

            "event_name",
            "details",
            "date",
            "start_time",
            "end_time",





        ]
