from django.db import models

# Create your models here.
from django.db import models


class Customer(models.Model):
    email=models.EmailField(max_length=50)


class Itinerary(models.Model):
    auto_increment_id = models.AutoField(primary_key=True)
    event_name=models.CharField(max_length=100)
    details=models.CharField(max_length=300, null = True, blank = True )
    date=models.CharField(max_length=20)
    start_time=models.CharField(max_length=20)
    end_time=models.CharField(max_length=20)
