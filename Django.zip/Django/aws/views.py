from django.shortcuts import render
import random,string
# Create your views here.
import os
import random, string
from .forms import CustomerForm, Itinerary
from django.core.mail import send_mail


def random_string(length=32, uppercase=True, lowercase=True, numbers=True  ):
    character_set=""
    if uppercase:
        character_set+=string.ascii_uppercase
    if lowercase:
        character_set+=string.ascii_lowercase
    if numbers:
        character_set+=string.punctuation
    if numbers:
        character_set+=string.digits



    return"".join(random.choice(character_set) for i in range(length))





def home(request):
    form = CustomerForm()
    x=random_string(16)


    if request.method =="POST":

        filled_form = CustomerForm(request.POST)
        if filled_form.is_valid():
            email=filled_form.cleaned_data['email']
            print(email)
            post = CustomerForm(request.POST)
            post.save()
            send_mail(
                'Your Generated Password',
                'Here is your password, please keep it in a safe spot then delete this email. \n'"\n"+x,
                'tharmon@gmail.com',
                [email],
                fail_silently=False,
            )

            new_form = CustomerForm
            x
        return render(request,'home.html',{'form':new_form,})




    # # if request.method =="POST":
        filled_form = CustomerForm(request.POST)
        if filled_form.is_valid():
            post=CustomerForm(request.POST)
            post.save()

            new_form=CustomerForm
            return render(request,'home.html',{'form':new_form,})
    else:
        return render(request,'home.html',{'form':form})


